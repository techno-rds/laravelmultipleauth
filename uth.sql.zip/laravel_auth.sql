--
-- Database: `laravel_auth`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `v_name` varchar(100) NOT NULL,
  `v_email` varchar(100) NOT NULL,
  `v_img` varchar(256) NOT NULL,
  `password` varchar(100) NOT NULL,
  `remember_token` varchar(100) NOT NULL,
  `v_access_code` varchar(100) NOT NULL,
  `e_type` enum('Admin','User') NOT NULL DEFAULT 'Admin',
  `e_status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `v_name`, `v_email`, `v_img`, `password`, `remember_token`, `v_access_code`, `e_type`, `e_status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'TestAdmin', 'testing.admin@gmail.com', '', '$2y$10$JXVaTMI2AtT8zYpLdwCiq.NLtTwXS/EOsDT9tExZydO7BtHDayvAm', 'd35o8xKqexNJTgs03ZEZbxoHAAHp11PpFq0tfsToSJTDnYUsf39dYz8G0C8U', '', 'Admin', 'Active', '2017-02-04 07:15:01', '2017-02-04 07:15:01', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `v_name` varchar(100) NOT NULL,
  `v_email` varchar(100) NOT NULL,
  `v_img` varchar(256) NOT NULL,
  `password` varchar(100) NOT NULL,
  `remember_token` varchar(100) NOT NULL,
  `v_access_code` varchar(100) NOT NULL,
  `e_status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `api_token` varchar(256) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `v_name`, `v_email`, `v_img`, `password`, `remember_token`, `v_access_code`, `e_status`, `api_token`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'TestUser', 'testing.demo@gmail.com', '', '$2y$10$9HwzBFgfkoppZZ19pQJHHuS69M3MmAIJu0S54ubO1jGmdlvnjNPRW', 'b0lPfu73ktpdUCfIIRZE0VlRd0vRuT8Gmlw5SBxIcmBafLYdpt3V9ps4T2li', '', 'Active', 'fHWzQFF2eXM9qaZgNuBxK89zwvwfFepkXAvCRbOt5vK3noArDI', '2017-02-04 07:14:23', '2017-02-04 07:14:23', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
